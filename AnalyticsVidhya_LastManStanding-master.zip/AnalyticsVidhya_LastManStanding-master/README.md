# AnalyticsVidhya_LastManStanding
Last Man Standing competition on AnalyticsVidhya

This code scored 0.9604 on the public LB and ranked 2nd.

P.S. The code can certainly be optimized and made it to run faster, but I leave that for people to try :-)
