This folder contains feature confs used to generate feature matrix (input) for Chenglong's models.

They are used in a similar way as following (excuted in the `./Code/Chenglong` directory):
`python feature_combiner.py -l 1 -c feature_conf_xxx -n basic_xxx -t 0.05`

Please see `feature_combiner.py`for the usage.