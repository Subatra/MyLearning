# Importing Baltimore's 2010 Monthly Crime Data
 
# create an object called bmore.crime from the csv file called Crime_2010_Count_By_District.csv
bmore.crime <- read.csv("~/cra/cra_projects/code_peoples-data/The People's Data/data_files/Crime_2010_Count_By_District.csv")
