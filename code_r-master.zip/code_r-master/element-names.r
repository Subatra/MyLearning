# Element Names

# Each element in a vector can have a name assigned to it

# Create a vector with names for values
percent.sms <- c(high = 94, low = 23, 50)

# List names of a vector
names(percent.sms)