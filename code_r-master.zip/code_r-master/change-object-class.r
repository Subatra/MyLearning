# Change The Class Of An Object

# Changing the class of an object is called "casting".

# Create a character string object
number.of.casualties <- "929040"

# Convert it into a numeric object
number.of.casualties <- as.numeric(number.of.casualties)
