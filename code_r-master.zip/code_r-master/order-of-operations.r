# Like in math class, we can prioritize the order of how R calculates things using parentheses

2 * 5 + 1 # multiply 2 and 5, then add 1
2 * (5 + 1) # add 5 and 1, then multiply by 2