# apropos functions finds objects and functions

# Create a vector with various kitten names
kitten.names <- c("Stacy", "McKiddleton", "Cat Number Two")

# Find any object and function with "kitten" in the name
apropos("kitten")