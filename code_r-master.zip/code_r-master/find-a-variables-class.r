#Classes

# Classes tell you what type a paticular variable is, whether numeric or logistic.

# Use the class() function to find out a variable's class

# Create a variable called "crime", containing numeric data
crime <- c(1,2,4,5)

# find the class of the variable "crime"
class(crime)