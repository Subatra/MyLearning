# Convert Strings To Objects

# Create a vector of strings
name <- c("John", "Jason", "Sarah")

# Create a variable from the first element of the "name" variable, called that element's string and give that variable from values.
assign(name[1], c(23,24,33,46,65,86))

# Display the variable "John"
John