# Create a sequences of numbers

# We can use the collem to create a sequence of integers.

# Create a sequence from 1 to 5, spread one number apart
1:5

# However, for more control we can use seq.int to specify the spacing the sequence

# Create a sequence from 1 to 10, spread 2.5 apart
seq.int(1, 10, 2.5)