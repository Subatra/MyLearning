# Find Unique Elements In Objects

# generate fake data
x <- c(4,5,6,2,3,6,7,8,4,5,7,8,3,3,6,7,8,3,2,5,7,8,4,2,6,7,3,2,4,6,7)

# find unique elements
unique(x)