# Installing and loading packages

# Install the package called "mapdata"
install.packages("mapdata")

# Load the package called "mapdata"
library(mapdata)