# Special Characters In Strings

## There are some special characters that can be added to strings by placing certain characters in the string. To view these characters we use cat() because the default print() converts these escape characters into regular characters.

# Add a tab
cat("cat\tdog")

# Add a line break
cat("cat\ndog")