# Albon's R Code

This is an unorganized collection of well documented R scripts and snippits for reuse.