# Generate Factor Levels
# Original source: Learning R

# Generate two factor levels, repeating once, and add labels
gl(2, 1, labels = c("male", "female"))