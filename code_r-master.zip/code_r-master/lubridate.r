# Lubridate Package

# THIS FILE IS BROKEN UNTIL CRAN FIXES LUBRIDATE LINK.

# Lubridate lubricates working with dates.

# load lubridate
library(lubridate)

my.birthday <- c(
  "1983-09-15"
  "1983/9\15")

ymd(my.birthday)