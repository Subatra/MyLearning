# Changing Uppercase And Lowercase

# create a character vector
text <- c("DSFGSsdffdsDSF", "DdsFDSFsdfSsdf", "DDDDDDDD", "kkkkkkkk")

# convert to upper case
toupper(text)

# convert to all lower case
tolower(text)