# Time Zones

# The time zones are specified by tz

# convert the system time to PST
strftime(Sys.time(), tz = "PST")