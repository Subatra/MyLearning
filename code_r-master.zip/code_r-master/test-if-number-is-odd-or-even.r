# Testing if a number is odd or even

# When you divide one number into another, sometimes you are left with a remainder. That remainder is called a modulo.

# If you divide an odd number in half, it will always have a remainder of 1.
173 %% 2 # what is the modulo value (i.e. the remainder) of 143 when divided by 2

# If you divide an even number in half, it will always have a remainder of 0.
40 %% 2 # what is the modulo value (i.e. the remainder) of 143 when divided by 2