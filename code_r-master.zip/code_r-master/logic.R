# We can ask R logic questions

# Logical operators
2 < 4 # 2 is less than 4
2 <= 4 # 2 is less than or equal to 4
2 > 4 # 2 is greater than 4
3 >= 5 # 3 is greater than or equal to 5
5 == 5 # 5 is equal to 5
5 != 4 # 5 is not equal to 4
!2 # Not 2
2 | 4 # 2 or 4
4 & 5 # 3 and 5
isTRUE(4 + 4 == 8) # is "4 plus 4 equals 5" true?