# Removing Variables

# Create two variables of 50 observations
percent.sms <- runif(50)
location <- state.name

# Remove the location variable
rm(location)