# Formatting Dates And Times

# Format the system time to make it more readable
strftime(Sys.time(), "It's %I:%M%p on %A %d %B %Y.")

