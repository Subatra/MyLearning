### Job postings

We've gotten a few requests to post jobs.  We will send everything we get to our [Office of Career Development]
(http://www.stern.nyu.edu/programs-admissions/full-time-mba/career/career-development),
but can post short things here if you think it would be useful.  

October 26, 2015.  MBA alum Casey Klippel, from IBM's Business Performance Services (BPS), reminds us that they will be on campus Thursday, October 29, 2015, 7pm, in KMC 1-100.  BPS is IBM's data-driven consulting group and uses Python extensively.  
