# Data Bootcamp:  Our Team  

This course reflects the collective effort of many people. It was Glenn Okun's idea. He really should have done it himself, but we thank him for the idea.  The course content was developed by Dave Backus, Sarah Beckett-Hile, Chase Coleman, and Spencer Lyon.  Many others contributed technical support and applications, among them Paul Backus, Hersh Iyer (MBA17), Matt McKay, Kim Ruhl, and Itamar Snir (MBA17).  You may also notice a family resemblance to Tom Sargent and John Stachurski's [Quantitative Economics](http://quant-econ.net/), a Python- and Julia-based course in dynamic macroeconomic theory.  This course is one of the byproducts of the environment they created.  



